package org.zjsru.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ProductController {
    //用数组接收请求参数
    @RequestMapping("/getProducts")
    public String getProducts(String[] proIds){
        for (String proId:proIds
             ) {
            System.out.println("获取到了Id为："+proId+"商品");
        }

        return "success";
    }
    //用集合接收请求参数
    @RequestMapping("/getProductsList")
    public String getProductsList(@RequestParam(value = "proIds") List<String> proIds){
        for (String proId:proIds
        ) {
            System.out.println("获取到了Id为："+proId+"商品");
        }

        return "success";
    }
}
