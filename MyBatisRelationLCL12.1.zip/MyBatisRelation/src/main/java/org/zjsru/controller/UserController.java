package org.zjsru.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.zjsru.domain.Order;
import org.zjsru.domain.UserInfo;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {
    @RequestMapping(value = "/tologin")
    //方法的形参名必须和请求的参数名一致
    public String login(String uname, String upass,Model model){
        System.out.println("用户名："+uname+","+"密码："+upass);
        if("zs".equals(uname)&&"123".equals(upass)){
            model.addAttribute("username",uname);
            return "forward:/user/tomain";
        }else{
            model.addAttribute("message","很遗憾，登录失败！");
            return "redirect:/login.jsp";
        }
    }

    @RequestMapping("/tologin2")
    //请求参数的名称必须和形参对象中的属性名一致
    //Model对象是框架自动创建的
    public String login2(UserInfo userInfo, Model model){
        if("zs".equals(userInfo.getUname())&&"123".equals(userInfo.getUpass())){
            model.addAttribute("username",userInfo.getUname());
            return "success";
        }else{
            return "failure";
        }
    }
    /*用来返回ModelAndView（存放视图和数据的）,需要用户自己创建*/
    @RequestMapping("/tologin3")
    //请求参数的名称必须和形参对象中的属性名一致
    public ModelAndView login3(UserInfo userInfo){
        ModelAndView mv = new ModelAndView();
        if("zs".equals(userInfo.getUname())&&"123".equals(userInfo.getUpass())){
            mv.setViewName("success");
            mv.addObject("userinfo",userInfo);
            return mv;
        }else{
            return mv;
        }
    }
    @RequestMapping(value = "/tologin4")
    //方法的形参名必须和请求的参数名一致
    public String login4(String uname, String upass,HttpSession session,HttpServletResponse response){
        System.out.println("用户名："+uname+","+"密码："+upass);
        if("zs".equals(uname)&&"123".equals(upass)){
            session.setAttribute("usernamebysession",uname);
          /*  Cookie cookie = new Cookie("uname",uname);
            cookie.setMaxAge(30*24*60*60);
            response.addCookie(cookie);
            Cookie cookie2 = new Cookie("upass",upass);
            cookie.setMaxAge(30*24*60*60);
            response.addCookie(cookie2);*/
            return "forward:/user/tomain";
        }else{

            return "redirect:/login.jsp";
        }
    }
    @RequestMapping("/tomain")
    public String main(UserInfo userInfo, HttpSession session, Model model){
        return "main";
       /* ModelAndView mav = new ModelAndView();
        if("zs".equals(userInfo.getUname())&&"123".equals(userInfo.getUpass()))
        {
            mav.addObject("msg","登录成功");
            // model.addAttribute("msg","登录成功");
            //session.setAttribute("userinfo",userInfo.getUname());
            // System.out.println(session.getAttribute("userinfo"));
            mav.setViewName("main");
            return mav;
        }else{
            mav.addObject("msg","很遗憾登录失败");
            mav.setViewName("/login.jsp");
            return mav;
        }*/
    }
    //如果没有返回值，则将请求URLpattern作为视图名
    @RequestMapping(value = "/tologinvoid")
    //方法的形参名必须和请求的参数名一致
    public void loginvoid(String uname, String upass){

        if("zs".equals(uname)&&"123".equals(upass)){
            System.out.println("用户名："+uname+","+"密码："+upass);
        }else{
            System.out.println("登录失败");
        }
    }
    //返回字符串
    @RequestMapping(value = "/tologinjson")
    @ResponseBody
    //方法的形参名必须和请求的参数名一致
    public String loginjson(String uname, String upass){

        if("zs".equals(uname)&&"123".equals(upass)){
            System.out.println("用户名："+uname+","+"密码："+upass);
            return "success";
        }else{
            return "failure";
        }
    }
    //返回对象
    @RequestMapping(value = "/tologinjson2")
    @ResponseBody
    //方法的形参名必须和请求的参数名一致
    public UserInfo loginjson2(String uname, String upass){
        UserInfo userInfo = new UserInfo();
        if("zs".equals(uname)&&"123".equals(upass)){
           userInfo.setUname(uname);
           userInfo.setUpass(upass);
            return userInfo;
        }else{
            return null;
        }
    }
    @RequestMapping(value = "/toregister")
    public String register(){
        return "register";
    }

    @RequestMapping("/findOrderWithUser")
    public String findOrderWithUser(UserInfo userInfo){
        String username = userInfo.getUname();
        Order order = userInfo.getOrder();
        String orderId = order.getOrderId();
        System.out.println("用户名："+username+","+"订单Id："+orderId);
        return "success";
    }
    //使session会话失效
    @RequestMapping(value = "/logout")
    public String logout(HttpSession session){
        /*清空session对象*/
        session.invalidate();
        return "redirect:/login.jsp";
    }

}
