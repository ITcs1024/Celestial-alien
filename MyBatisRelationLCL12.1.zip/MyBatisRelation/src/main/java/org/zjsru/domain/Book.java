package org.zjsru.domain;

import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName book
 */
@Data
public class Book implements Serializable {
    /**
     * 
     */
    private Integer bid;

    /**
     * 
     */
    private String bname;

    /**
     * 
     */
    private String bpress;


}