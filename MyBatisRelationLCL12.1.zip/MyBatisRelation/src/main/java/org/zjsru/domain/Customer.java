package org.zjsru.domain;

import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName t_customer
 */
@Data
public class Customer implements Serializable {
    /**
     * 
     */
    private Integer id;

    /**
     * 
     */
    private String username;

    /**
     * 
     */
    private String cjobs;

    /**
     * 
     */
    private String cphone;

    private static final long serialVersionUID = 1L;
}