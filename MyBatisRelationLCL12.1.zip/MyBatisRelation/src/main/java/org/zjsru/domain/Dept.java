package org.zjsru.domain;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

/**
 * 
 * @TableName tb_client
 */
@Data
public class Dept implements Serializable {
    /**
     * 用户ID
     */
    private Integer id;

    /**
     * 用户姓名
     */
    private String username;

    /**
     * 用户地址
     */
    private String address;

    private Emp ordersList;

    private static final long serialVersionUID = 1L;
}