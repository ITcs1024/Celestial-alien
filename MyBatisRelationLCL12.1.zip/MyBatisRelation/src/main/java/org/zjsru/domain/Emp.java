package org.zjsru.domain;

import lombok.Data;

@Data
public class Emp {
    private Integer id;
    private String name;
    private Integer age;
    private String depId;
}
