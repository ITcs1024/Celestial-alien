package org.zjsru.domain;

import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName tb_idcard
 */
@Data
public class Idcard implements Serializable {
    /**
     * 
     */
    private Integer id;

    /**
     * 
     */
    private String code;

    private static final long serialVersionUID = 1L;
}