package org.zjsru.domain;

import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName tb_orders
 */
@Data
public class Orders implements Serializable {
    /**
     * 
     */
    private Integer id;

    /**
     * 
     */
    private String number;

    /**
     * 
     */
    private Integer userId;

    private static final long serialVersionUID = 1L;
}