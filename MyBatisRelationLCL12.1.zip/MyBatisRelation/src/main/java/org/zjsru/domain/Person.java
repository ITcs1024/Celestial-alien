package org.zjsru.domain;

import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName tb_person
 */
@Data
public class Person implements Serializable {
    /**
     * 
     */
    private Integer id;

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private Integer age;

    /**
     * 
     */
    private String sex;

    /**
     * 
     */
    //private Integer cardId;
    private Idcard card;//人员关联的身份证信息

    private static final long serialVersionUID = 1L;
}