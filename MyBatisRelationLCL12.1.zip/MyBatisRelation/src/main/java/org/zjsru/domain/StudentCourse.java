package org.zjsru.domain;

import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName tb_student_course
 */
@Data
public class StudentCourse implements Serializable {
    /**
     * 
     */
    private Integer id;

    /**
     * 
     */
    private Integer studentId;

    /**
     * 
     */
    private Integer courseId;

    private static final long serialVersionUID = 1L;
}