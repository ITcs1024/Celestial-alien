package org.zjsru.domain;

import lombok.Data;

@Data
public class User {
    private int uid;
    private String uname;
    private int uage;

}
