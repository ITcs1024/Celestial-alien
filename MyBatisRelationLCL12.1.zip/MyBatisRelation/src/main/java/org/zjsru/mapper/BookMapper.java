package org.zjsru.mapper;

import org.zjsru.domain.Book;

import java.util.List;

/**
* @author Administrator
* @description 针对表【book】的数据库操作Mapper
* @createDate 2023-11-14 09:29:32
* @Entity org.zjsru.domain.Book
*/
public interface BookMapper {

    int deleteByPrimaryKey(Long id);

    int insert(Book record);

    int insertSelective(Book record);

    Book selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Book record);

    int updateByPrimaryKey(Book record);
    List<Book> selectAll();

}
