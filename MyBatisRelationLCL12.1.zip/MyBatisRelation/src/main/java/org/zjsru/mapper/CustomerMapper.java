package org.zjsru.mapper;

import org.zjsru.domain.Customer;

import java.util.ArrayList;
import java.util.List;

/**
* @author Administrator
* @description 针对表【t_customer】的数据库操作Mapper
* @createDate 2023-11-21 08:33:11
* @Entity org.zjsru.domain.Customer
*/
public interface CustomerMapper {

    int deleteByPrimaryKey(Long id);

    int insert(Customer record);

    int insertSelective(Customer record);

    /*Customer selectByPrimaryKey(Long id);*/

    int updateByPrimaryKeySelective(Customer record);

    int updateByPrimaryKey(Customer record);

    List<Customer> findCustomerByNameAndJobs(Customer customer);
    List<Customer> findCustomerByNameOrJobs(Customer customer);

    List<Customer> findCustomerByArray(Integer[] rolesId);
    List<Customer> findCustomerByList(List<Integer> rolesId);
    List<Customer> findAll();

}
