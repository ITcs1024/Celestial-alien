package org.zjsru.mapper;

import org.zjsru.domain.Dept;

import java.util.List;

/**
 * @author zero
 * @description 针对表【tb_client】的数据库操作Mapper
 * @createDate 2023-11-29 09:34:53
 * @Entity org.zjsru.domain.Client
 */
public interface DeptMapper {

    int deleteByPrimaryKey(Long id);

    int insert(Dept record);

    int insertSelective(Dept record);

    Dept selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Dept record);

    int updateByPrimaryKey(Dept record);
    List<Dept> findDeptWithOrders(Integer id);
}
