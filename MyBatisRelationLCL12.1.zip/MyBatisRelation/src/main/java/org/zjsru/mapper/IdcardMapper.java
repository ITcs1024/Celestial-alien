package org.zjsru.mapper;

import org.zjsru.domain.Idcard;

/**
* @author Administrator
* @description 针对表【tb_idcard】的数据库操作Mapper
* @createDate 2023-11-28 08:44:17
* @Entity org.zjsru.domain.Idcard
*/
public interface IdcardMapper {

    int deleteByPrimaryKey(Long id);

    int insert(Idcard record);

    int insertSelective(Idcard record);

    Idcard selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Idcard record);

    int updateByPrimaryKey(Idcard record);

}
