package org.zjsru.mapper;

import org.zjsru.domain.Orders;

/**
* @author 醉美拯救姬
* @description 针对表【tb_orders】的数据库操作Mapper
* @createDate 2023-11-29 09:29:20
* @Entity org.zjsru.domain.Orders
*/
public interface OrdersMapper {

    int deleteByPrimaryKey(Long id);

    int insert(Orders record);

    int insertSelective(Orders record);

    Orders selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Orders record);

    int updateByPrimaryKey(Orders record);

}
