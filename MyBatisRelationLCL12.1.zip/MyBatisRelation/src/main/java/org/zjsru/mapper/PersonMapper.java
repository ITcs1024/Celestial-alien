package org.zjsru.mapper;

import org.zjsru.domain.Person;

/**
* @author Administrator
* @description 针对表【tb_person】的数据库操作Mapper
* @createDate 2023-11-28 08:44:42
* @Entity org.zjsru.domain.Person
*/
public interface PersonMapper {

    Person findPersonById2(Integer id);
    int deleteByPrimaryKey(Long id);

    int insert(Person record);

    int insertSelective(Person record);

    Person selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Person record);

    int updateByPrimaryKey(Person record);

    Person findPersonWithCodeById(Integer id);

}
