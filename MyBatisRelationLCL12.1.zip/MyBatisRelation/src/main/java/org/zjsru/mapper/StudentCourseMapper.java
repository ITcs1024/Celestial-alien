package org.zjsru.mapper;

import org.zjsru.domain.StudentCourse;

/**
* @author 醉美拯救姬
* @description 针对表【tb_student_course】的数据库操作Mapper
* @createDate 2023-12-01 13:25:05
* @Entity org.zjsru.domain.StudentCourse
*/
public interface StudentCourseMapper {

    int deleteByPrimaryKey(Long id);

    int insert(StudentCourse record);

    int insertSelective(StudentCourse record);

    StudentCourse selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(StudentCourse record);

    int updateByPrimaryKey(StudentCourse record);

}
