package org.zjsru.mapper;

import org.zjsru.domain.Dept;
import org.zjsru.domain.FindStudentWithOrdersDtoD;
import org.zjsru.domain.Student;

import java.util.List;

/**
* @author 醉美拯救姬
* @description 针对表【tb_student】的数据库操作Mapper
* @createDate 2023-12-01 13:22:51
* @Entity org.zjsru.domain.Student
*/
public interface StudentMapper {

    int deleteByPrimaryKey(Long id);

    int insert(Student record);

    int insertSelective(Student record);

    Student selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Student record);

    int updateByPrimaryKey(Student record);
    List<FindStudentWithOrdersDtoD> findStudentWithOrders(Integer id);

}
