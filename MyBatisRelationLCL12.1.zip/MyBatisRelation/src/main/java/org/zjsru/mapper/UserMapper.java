package org.zjsru.mapper;

import org.zjsru.domain.User;

import java.util.List;

public interface UserMapper {
    public List<User> findAll();
    int addUser(User user);
    int deleteUser(int id);
    int updateUser(User user);
    List<User> findUserByName(String username);
}
