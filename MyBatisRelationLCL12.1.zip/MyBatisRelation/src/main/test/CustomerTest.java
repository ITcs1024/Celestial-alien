
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.zjsru.domain.Customer;
import org.zjsru.domain.User;
import org.zjsru.mapper.CustomerMapper;
import org.zjsru.mapper.UserMapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.apache.ibatis.io.Resources.getResourceAsStream;

public class CustomerTest {
    SqlSession session = null;
    CustomerMapper customerMapper = null;
    @Before
    public void preConnect() throws IOException {
        String resource = "mybatis-config.xml";
        //1.读取配置文件，获取输入流
        InputStream inputStream = getResourceAsStream(resource);
        //2.初始化mybatis数据库，创建sqlSessionFactory类的实例
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //3.创建sqlsession实例
        session = sqlSessionFactory.openSession();
        customerMapper = session.getMapper(CustomerMapper.class);
    }

    @Test
    public void findCustomerByNameAndJobs(){
        Customer customer = new Customer();
       /* customer.setUsername("joy");*/
        //customer.setJobs("teacher");
        List<Customer> customerByNameAndJobs = customerMapper.findCustomerByNameAndJobs(customer);
        System.out.println(customerByNameAndJobs);
    }
    @Test
    public void findCustomerByNameOrJobs(){
        Customer customer = new Customer();
        customer.setUsername("joy");
        //customer.setJobs("student");
        List<Customer> customerByNameAndJobs = customerMapper.findCustomerByNameOrJobs(customer);
        System.out.println(customerByNameAndJobs);
    }
    @Test
    public void updateCustomerById(){
        Customer customer = new Customer();
        customer.setUsername("lily");
        customer.setId(1);
        int i = customerMapper.updateByPrimaryKey(customer);
        System.out.println(i);
    }

    @Test
    public void findCustomerByArrayTest(){
        Integer[] rolesId = {2,4};
        List<Customer> customerByArray = customerMapper.findCustomerByArray(rolesId);
        System.out.println(customerByArray);
    }
    @Test
    public void findCustomerByListTest(){
       List<Integer> rolesId = new ArrayList<>();
       rolesId.add(2);
       rolesId.add(3);
        List<Customer> customerByArray = customerMapper.findCustomerByList(rolesId);
        System.out.println(customerByArray);
    }
    @Test
    public void findAllTest(){
        List<Customer> customerList = customerMapper.findAll();
        System.out.println(customerList);
    }
    @After
    public void after(){

        session.commit();
        session.close();
    }
}
