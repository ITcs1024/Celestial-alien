import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.zjsru.domain.FindStudentWithOrdersDtoD;
import org.zjsru.domain.Student;
import org.zjsru.mapper.StudentMapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import static org.apache.ibatis.io.Resources.getResourceAsStream;

public class StudentManyToManyTest {
    SqlSession session = null;
    StudentMapper studentMapper = null;

    @Before
    public void preConnect() throws IOException {
        String resource = "mybatis-config.xml";
        //1.读取配置文件，获取输入流
        InputStream inputStream = getResourceAsStream(resource);
        //2.初始化mybatis数据库，创建sqlSessionFactory类的实例
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //3.创建sqlsession实例
        session = sqlSessionFactory.openSession();
        studentMapper = session.getMapper(StudentMapper.class);
    }

    @Test
    public void findStudentWithOrdersTest(){
        List<FindStudentWithOrdersDtoD> studentWithOrders=studentMapper.findStudentWithOrders(2);
        System.out.println(studentWithOrders);
    }  //202105015416 李承霖

    @After
    public void after(){

        session.commit();
        session.close();
    }
}
