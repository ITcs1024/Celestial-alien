
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.zjsru.domain.User;
import org.zjsru.mapper.UserMapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.List;

import static org.apache.ibatis.io.Resources.getResourceAsStream;

public class UserTest {
    SqlSession session = null;
    UserMapper userMapper = null;
    @Before
    public void preConnect() throws IOException {
        String resource = "mybatis-config.xml";
        //1.读取配置文件，获取输入流
        InputStream inputStream = getResourceAsStream(resource);
        //2.初始化mybatis数据库，创建sqlSessionFactory类的实例
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //3.创建sqlsession实例
        session = sqlSessionFactory.openSession();
        userMapper = session.getMapper(UserMapper.class);
    }
    @Test
    public void selectAllTest(){
        //List<User> userList = session.selectList("findAll");
        List<User> all = userMapper.findAll();
        System.out.println(all);
    }
    @Test
    public void addUserTest(){
        User user = new User();
        user.setUage(12);
        user.setUname("ricky");
        int addUser = session.insert("addUser", user);
        System.out.println(addUser);
    }
    @Test
    public void deleteUserTest(){
        int i = userMapper.deleteUser(6);
        System.out.println(i);
    }
    @Test
    public void updateUserTest(){
        User user = new User();
        user.setUid(1);
        user.setUage(12);
        user.setUname("ricky");
        int i = userMapper.updateUser(user);
        System.out.println(i);
    }
    @After
    public void after(){

        session.commit();
        session.close();
    }
}
